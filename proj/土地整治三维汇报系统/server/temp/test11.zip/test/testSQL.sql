﻿truncate table country_village_tree;
alter sequence cvt_gid_seq restart with 1;
insert into country_village_tree ( from_table, id, parent) values ('county',0,0);

insert into country_village_tree ( from_table, id, parent)
(select  'country', gid, (select x.gid from country_village_tree x where parent=0) from country c
where not exists (select 1 from country_village_tree ct 
where ct.id = c.gid and ct.from_table = 'country'));

insert into country_village_tree ( from_table, id, parent)
(select  'village', 
ov.gid, 
(select cv.gid from country c,village v,country_village_tree cv 
where ST_Area(ST_Intersection(c.geom,v.geom)) > (v.kzmj/10)
and v.gid = ov.gid 
and cv.from_table = 'country' 
and cv.id = c.gid) 
from village ov
where not exists (select 1 from country_village_tree ct 
where ct.id = ov.gid and ct.from_table = 'village'));

insert into country_village_tree ( from_table, id, parent)
(select  'plan', 
op.gid,
(select cv.gid from village v, plan p, country_village_tree cv 
--where ST_Contains(v.geom, p.geom)
where ST_Area(ST_Intersection(v.geom,p.geom)) > (p.shape_area/10)
and p.gid = op.gid
and cv.from_table = 'village' 
and cv.id = v.gid)
from plan op
where not exists (select 1 from country_village_tree ct
where ct.id = op.gid and ct.from_table = 'plan'));

insert into country_village_tree ( from_table, id, parent)
(select  'spot', 
os.gid,
(select cv.gid from village v, spot s, country_village_tree cv 
--where ST_Contains(v.geom, s.geom) 
where ST_Area(ST_Intersection(v.geom,s.geom)) > (s.shape_area/10)
and s.gid = os.gid
and cv.from_table = 'village' 
and cv.id = v.gid)
from spot os
where not exists (select 1 from country_village_tree ct 
where ct.id = os.gid and ct.from_table = 'spot'));

insert into country_village_tree ( from_table, id, parent)
(select  'attachment', 
oa.gid,
oa.attach_to_id
from attachments oa
where not exists (select 1 from country_village_tree ct 
where ct.parent = oa.attach_to_id and ct.id = oa.gid));

insert into attachment ( attach_to_id, file_type, name)
values (184,'PDF','test4' )


-- get tree
select cvt.parent, cvt.gid, cvt.id, cvt.from_table,
case
 when cvt.from_table = 'country' then
	(select c.name as label from country c where c.gid = cvt.id and cvt.from_table = 'country')
 when cvt.from_table = 'village' then
	(select v.name as label from village v where v.gid = cvt.id and cvt.from_table = 'village')
 when cvt.from_table = 'spot' then
	(select s.objectid as label from spot s where s.gid = cvt.id and cvt.from_table = 'spot')
 when cvt.from_table = 'plan' then
	(select p.objectid as label from plan p where p.gid = cvt.id and cvt.from_table = 'plan')
 when cvt.from_table = 'attachments' then
	(select concat(a.file_name,'.',a.file_type) as label from attachments a where a.gid = cvt.id and cvt.from_table = 'attachments')
end as label
from country_village_tree cvt 



select cvt.parent, cvt.gid, cvt.id, cvt.from_table,
      case
	      when cvt.from_table = 'country' then
		(select c.name as label from country c where c.gid = cvt.id and cvt.from_table = 'country')
	      when cvt.from_table = 'village' then
		(select v.name as label from village v where v.gid = cvt.id and cvt.from_table = 'village')
	      when cvt.from_table = 'spot' then
		(select s.objectid as label from spot s where s.gid = cvt.id and cvt.from_table = 'spot')
	      when cvt.from_table = 'plan' then
		(select p.objectid as label from plan p where p.gid = cvt.id and cvt.from_table = 'plan')
	      else
		'县'
      end as label
from country_village_tree cvt where not cvt.from_table = 'attachments'

create type attach_type as enum ('zzq_img','zzh_img');

alter table attachments 
	alter column attach_type type attach_type using attach_type::attach_type


















insert into attachments(attach_to_id, file_type,file_name,attach_type) values (188,'gif','asdfas','zzq_img') 
on conflict(select gid from attachments where attach_to_id=188 and attach_type='zzq_img') do update set file_type = 'gif', file_name = 'asdfas'





insert into country_village_tree ( from_table, id, parent)
(select  'attachment', 
oa.attach_to_id,
(select cv.gid from country_village_tree cv, attachment a
where a.attach_to_id = oa.attach_to_id 
and a.attach_to_table = oa.attach_to_table 
and cv.from_table = a.attach_to_table
and cv.id = a.attach_to_id)
from attachment oa
where not exists (select 1 from country_village_tree ct 
where ct.id = oa.attach_to_id and ct.from_table = 'attachment'));






select 
v.name as name,
v.id as id,
v.objectid as cObjectid,
c.name as pName, 
c.id as parent, 
c.objectid as pObjectid   
from village v,country c 
where v.geom && c.geom 
and ST_Contains(c.geom,v.geom)

select 
v.name as name,
v.gid as gid,
v.objectid as cObjectid,
p.id as planid  
from village v,plan p 
where v.geom && p.geom 
and ST_Contains(v.geom,p.geom)

select gid from country_village_tree c where c.from_table='village' and id = (
select
v.id
from village v,spot s
where v.geom && s.geom
and ST_Contains(v.geom,s.geom)) 

select v.name as name, v.id as id, v.objectid as cObjectid, s.id as spotid into village_spot from village v,spot s where v.geom && s.geom and ST_Contains(v.geom,s.geom);

alter table country_village_tree add primary key (gid) ;


ALTER TABLE public.country_village_tree ADD COLUMN gid integer;
ALTER TABLE public.country_village_tree ALTER COLUMN gid SET NOT NULL;
ALTER TABLE public.country_village_tree ALTER COLUMN gid SET DEFAULT nextval('plan_gid_seq'::regclass);

select item_id, name, item_group from items where item_id=2


truncate table country_village_tree;
insert into country_village_tree ( from_table, id, parent) values ('county',0,0)



select cv.gid, MAX(ST_Area(ST_Intersection(c.geom,v.geom))) from country c,village v,country_village_tree cv 
where cv.from_table = 'country' 
and cv.id = c.gid group by cv.gid


select  'village', 
ov.gid, 
(select cv.gid,MAX(ST_Area(ST_Intersection(c.geom,v.geom))) from country c,village v,country_village_tree cv 
where v.gid = ov.gid 
and cv.from_table = 'country' 
and cv.id = c.gid group by cv.gid) 
from village ov
where not exists (select 1 from country_village_tree ct 
where ct.id = ov.gid and ct.from_table = 'village')


SELECT tt.*,groupedtt.*
FROM village tt
INNER JOIN
    (select cv.gid as ggid,MAX(ST_Area(ST_Intersection(c.geom,v.geom))) as maxs from country c,village v,country_village_tree cv 
where cv.from_table = 'country' 
and cv.id = c.gid group by cv.gid) groupedtt 
ON tt.gid = groupedtt.ggid
where 


SELECT a.gid
FROM (select cv.gid as gid,MAX(ST_Area(ST_Intersection(c.geom,v.geom))) as maxs from country c,village v,country_village_tree cv 
where cv.from_table = 'country' 
and cv.id = c.gid group by cv.gid) a
INNER JOIN (
    select cv.gid as gid,MAX(ST_Area(ST_Intersection(c.geom,v.geom))) as maxs from country c,village v,country_village_tree cv 
where cv.from_table = 'country' 
and cv.id = c.gid group by cv.gid) c
 ON a.gid = c.gid AND a.maxs = c.maxs

select MAX(ST_Area(ST_Intersection(c.geom,v.geom))) as maxs from country c,village v,country_village_tree cv 
where cv.from_table = 'country' 
and cv.id = c.gid 

select cv.gid as ggid,v.gid,MAX(ST_Area(ST_Intersection(c.geom,v.geom))) as maxs from country c,village v,country_village_tree cv 
where cv.from_table = 'country' 
and cv.id = c.gid group by cv.gid , v.gid