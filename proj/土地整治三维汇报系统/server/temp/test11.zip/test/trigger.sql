﻿CREATE OR REPLACE FUNCTION check_and_insert_plan()
RETURNS TRIGGER AS $$
BEGIN
	case
		---ST_Overlaps(NEW.geom, OLD.geom) then 
		when not NEW.objectid = OLD.objectid then
			UPDATE plan set geom = NEW.geom;
		else INSERT INTO plan(objectid, geom, ystbbh, flmc, shape_area, xzqdm,  xzqmc) values(NEW.objectid, NEW.geom,NEW.ystbbh,NEW.flmc,NEW.shape_area,NEW.xzqdm, NEW.xzqmc);
	end case;
	RETURN NULL;
END;
$$
LANGUAGE plpgsql;



CREATE TRIGGER plan_trigger
	AFTER UPDATE ON plan_temp
	FOR EACH ROW EXECUTE PROCEDURE check_and_insert_plan()



select ST_Intersects('0106000020C211000001000000010300000001000000050000008A95EDE8508D1E4118DF182B373D4E418A95EDE8508D1E4153CAFBE55F564E41D2A5176AA0121F4153CAFBE55F564E41D2A5176AA0121F4118DF182B373D4E418A95EDE8508D1E4118DF182B373D4E41', pt.geom) from plan p, plan_temp pt where p.gid = 4 and pt.gid = 5


insert into plan_temp(objectid,geom) values(15,'0106000020C21100000100000001030000000100000005000000D6EBC106E52B1F418FFE2AC0271F4E41D6EBC106E52B1F4129037DC71D374E41C2BBA2402A9D1F4129037DC71D374E41C2BBA2402A9D1F418FFE2AC0271F4E41D6EBC106E52B1F418FFE2AC0271F4E41')

create or replace function trigger_plan_function()
returns trigger as $$
begin
	--insert into plan values(NEW.*,1233);
	--return null;
	IF
		(select 1 from plan p where ST_Intersects(NEW.geom, p.geom)) then 
		UPDATE plan set geom = NEW.geom, objectid = NEW.objectid where gid = (select gid from plan p where ST_Intersects(NEW.geom, p.geom));
		else INSERT INTO plan values(NEW.*);
	end IF;
	RETURN NEW;
end;
$$
language plpgsql;

create trigger plan_trigger
	after insert on plan_temp
	FOR EACH ROW execute procedure trigger_plan_function();





























select 1 ST_Overlaps(ST_GeomFromText('MultiPolygon(0106000020C21100000100000001030000000100000005000000D6EBC106E52B1F418FFE2AC0271F4E41D6EBC106E52B1F4129037DC71D374E41C2BBA2402A9D1F4129037DC71D374E41C2BBA2402A9D1F418FFE2AC0271F4E41D6EBC106E52B1F418FFE2AC0271F4E41)',4546),ST_GeomFromText('MultiPolygon(0106000020C21100000100000001030000000100000005000000D6EBC106E52B1F418FFE2AC0271F4E41D6EBC106E52B1F4129037DC71D374E41C2BBA2402A9D1F4129037DC71D374E41C2BBA2402A9D1F418FFE2AC0271F4E41D6EBC106E52B1F418FFE2AC0271F4E41)',4546))




























create or table tarigger_detail (
	a text,
	b text,
	c text,
	d text,
	e text
)



create table tarigger_detail_temp (
	a text,
	b text,
	c text,
	d text,
	e text
)
insert into plan_temp values('a','a','a','a')